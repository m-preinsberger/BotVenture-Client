﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BotVenture
{
    public class Position
    {
        public int? Left {  get; set; }
        public int? Right { get; set; }
    }
}
