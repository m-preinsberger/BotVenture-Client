﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BotVenture
{
    public enum Level
    {
        level0,
        level1,
        level2,
        level3,
        level8,
    }
}
